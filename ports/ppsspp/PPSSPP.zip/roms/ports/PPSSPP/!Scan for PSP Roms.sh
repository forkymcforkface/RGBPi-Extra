#!/bin/bash

# Define the directory where this script resides
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Directory to scan for ROMs (ROMS folder in the same directory as the script)
ROMS_DIR="$SCRIPT_DIR/ROMS"

# Store the script file name
THIS_SCRIPT=$(basename -- "$0")

# Delete existing script files (excluding the script itself)
for script_file in "$SCRIPT_DIR"/*.sh; do
    if [ "$script_file" != "$SCRIPT_DIR/$THIS_SCRIPT" ]; then
        rm -f "$script_file"
    fi
done

# Iterate through each ROM file in the ROMS_DIR directory
for rom_file in "$ROMS_DIR"/*.iso "$ROMS_DIR"/*.cso; do
    # Check if there are any matching files
    if [ -e "$rom_file" ]; then
        # Get the base name of the ROM file without extension
        filename=$(basename -- "$rom_file")
        rom_name="${filename%.*}"

        # Create the script file name based on the ROM file name
        script_file="$SCRIPT_DIR/${rom_name}.sh"

        # Create the script file with the template and insert ROM name
        cat <<EOF >"$script_file"
#!/bin/bash
DIR="\$(cd "\$(dirname "\${BASH_SOURCE[0]}")" && pwd)"
cd "\$DIR" || exit

# Template script content with ROM name inserted
template_script() {
    timings=(
        "320 1 20 32 45 240 1 2 3 16 0 0 0 60.000000 0 6514560 1"
        "720 1 46 69 100 480 1 3 6 34 0 0 0 30 1 14670150 1"
        "720 1 29 69 117 576 1 7 6 38 0 0 0 25 1 14656125 1"
        "640 1 41 61 89 480 1 3 6 34 0 0 0 30 1 13038390 1"
    )

    file="/opt/rgbpi/ui/data/timings.dat"
    > "\$file"
    for line in "\${timings[@]}"; do
        echo "\$line" >> "\$file"
    done

    pkill -STOP python
    dd if=/dev/null | ./PPSSPP/drm-framebuffer -d /dev/dri/card1 -c VGA-1 -s 3 &
    ./PPSSPP/PPSSPPSDL "ROMS/${filename}"
    pkill drm-framebuffer
    pkill -CONT python
}

template_script
EOF

        # Make the script file executable
        chmod +x "$script_file"

        # Output the ROM found and the corresponding .sh file created
        echo "ROM found: $rom_name"
        echo "Script created: $script_file"
    fi
done
