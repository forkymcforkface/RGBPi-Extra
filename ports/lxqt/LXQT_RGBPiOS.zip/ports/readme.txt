Make sure you are on the internet
Copy all files to ports or a folder within ports, they can be run from anywhere. 
scan for games
Run STEP1_LXQT_install, it can take up to 10 minutes to run. The system will reboot itself when done
Run STEP2_LXQT_config, this will configure the desktop
run Desktop.sh to bring up the desktop.
You can now delete LXQT_install and LXQP_config if you would like.